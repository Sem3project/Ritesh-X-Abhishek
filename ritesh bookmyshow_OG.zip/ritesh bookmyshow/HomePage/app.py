


# from flask import Flask, jsonify, request
# from flask_cors import CORS
# import mysql.connector
# from datetime import datetime

# app = Flask(__name__)
# CORS(app)

# # Function to connect to the MySQL database
# def connect_db():
#     try:
#         conn = mysql.connector.connect(
#             host='localhost',
#             user='root',
#             password='ritesh@7506',
#             database='listing_movies'
#         )
#         return conn
#     except mysql.connector.Error as err:
#         print(f"Error: {err}")
#         return None

# # Function to format movie data
# def format_movie_data(movie):
#     return {
#         "id": movie[0],
#         "poster_url": movie[1] or 'default-poster.jpg',
#         "title": movie[2] or 'No title available',
#         "rating": float(movie[3]) if movie[3] is not None else 'N/A',
#         "type": movie[4] or 'Type not available',
#         "description": movie[5] or 'No description available'
#     }

# # API route to get all movies data from the `movies` table
# @app.route('/getMovies', methods=['GET'])
# def get_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM movies")
#     listing_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     movie_list = [format_movie_data(movie) for movie in listing_movies]
#     return jsonify(movie_list)

# # API route to get recommended movies
# @app.route('/getRecommendedMovies', methods=['GET'])
# def get_recommended_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM recommendedMovies")
#     recommended_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     recommended_list = [format_movie_data(movie) for movie in recommended_movies]
#     return jsonify(recommended_list)

# # API route to get popular movies
# @app.route('/getPopularMovies', methods=['GET'])
# def get_popular_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM popularMovies")
#     popular_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     popular_list = [format_movie_data(movie) for movie in popular_movies]
#     return jsonify(popular_list)

# # API route to get all movies data from the `allMovies` table
# @app.route('/getAllMovies', methods=['GET'])
# def get_all_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM allMovies")
#     all_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     all_movies_list = [format_movie_data(movie) for movie in all_movies]
#     return jsonify(all_movies_list)

# # API route to get movie details by ID and source
# @app.route('/getMovieDetail', methods=['GET'])
# def get_movie_detail():
#     movie_id = request.args.get('id')
#     source = request.args.get('source', 'allMovies')  # Default to 'allMovies'

#     print(f"Received movie_id: {movie_id}, source: {source}")

#     if not movie_id:
#         return jsonify({"error": "No movie ID provided"}), 400

#     if source not in ['movies', 'recommendedMovies', 'popularMovies', 'allMovies']:
#         return jsonify({"error": "Invalid source"}), 400

#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute(f"SELECT * FROM {source} WHERE id = %s", (movie_id,))
#     movie = cursor.fetchone()
#     cursor.close()
#     conn.close()

#     if movie:
#         movie_data = format_movie_data(movie)
#         return jsonify(movie_data)
#     else:
#         print(f"Movie with ID {movie_id} not found in {source} table")
#         return jsonify({"error": "Movie not found"}), 404

# # API route to get theater data
# @app.route('/getTheaters', methods=['GET'])
# def get_theaters():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM theaters")
#     theaters = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     theater_list = []
#     for theater in theaters:
#         theater_data = {
#             "id": theater[0],
#             "name": theater[1],
#             "location": theater[2],
#             "show_date": theater[3].strftime('%Y-%m-%d') if isinstance(theater[3], datetime) else theater[3],
#             "address": theater[4]
#         }
#         theater_list.append(theater_data)

#     return jsonify(theater_list)

# @app.route('/submitMessage', methods=['POST'])
# def submit_message():
#     try:
#         data = request.get_json()  # Get the data from the frontend
#         name = data.get('name')
#         email = data.get('email')
#         message = data.get('message')

#         # Ensure all fields are provided
#         if not name or not email or not message:
#             return jsonify({"error": "All fields are required"}), 400

#         # Connect to the database
#         conn = connect_db()
#         if not conn:
#             return jsonify({"error": "Database connection failed"}), 500

#         cursor = conn.cursor()

#         # Insert the message into the contactMessages table
#         query = "INSERT INTO contactMessages (name, email, message) VALUES (%s, %s, %s)"
#         cursor.execute(query, (name, email, message))
#         conn.commit()

#         cursor.close()
#         conn.close()

#         return jsonify({"success": "Message submitted successfully!"})

#     except Exception as e:
#         print(f"Error: {e}")
#         return jsonify({"error": "Internal server error"}), 500


# # Run the app
# if __name__ == '__main__':
#     app.run(debug=True)















# from flask import Flask, jsonify, request
# from flask_cors import CORS
# import mysql.connector
# from datetime import datetime

# app = Flask(__name__)
# CORS(app)

# # Function to connect to the MySQL database
# def connect_db():
#     try:
#         conn = mysql.connector.connect(
#             host='localhost',
#             user='root',
#             password='ritesh@7506',
#             database='listing_movies'
#         )
#         return conn
#     except mysql.connector.Error as err:
#         print(f"Error: {err}")
#         return None

# # Function to format movie data
# def format_movie_data(movie):
#     return {
#         "id": movie[0],
#         "poster_url": movie[1] or 'default-poster.jpg',
#         "title": movie[2] or 'No title available',
#         "rating": float(movie[3]) if movie[3] is not None else 'N/A',
#         "type": movie[4] or 'Type not available',
#         "description": movie[5] or 'No description available'
#     }

# # API route to get all movies data from the `movies` table
# @app.route('/getMovies', methods=['GET'])
# def get_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM movies")
#     listing_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     movie_list = [format_movie_data(movie) for movie in listing_movies]
#     return jsonify(movie_list)

# # API route to get recommended movies
# @app.route('/getRecommendedMovies', methods=['GET'])
# def get_recommended_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM recommendedMovies")
#     recommended_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     recommended_list = [format_movie_data(movie) for movie in recommended_movies]
#     return jsonify(recommended_list)

# # API route to get popular movies
# @app.route('/getPopularMovies', methods=['GET'])
# def get_popular_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM popularMovies")
#     popular_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     popular_list = [format_movie_data(movie) for movie in popular_movies]
#     return jsonify(popular_list)

# # API route to get all movies data from the `allMovies` table
# @app.route('/getAllMovies', methods=['GET'])
# def get_all_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM allMovies")
#     all_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     all_movies_list = [format_movie_data(movie) for movie in all_movies]
#     return jsonify(all_movies_list)

# # API route to get movie details by ID and source
# @app.route('/getMovieDetail', methods=['GET'])
# def get_movie_detail():
#     movie_id = request.args.get('id')
#     source = request.args.get('source', 'allMovies')  # Default to 'allMovies'

#     print(f"Received movie_id: {movie_id}, source: {source}")

#     if not movie_id:
#         return jsonify({"error": "No movie ID provided"}), 400

#     if source not in ['movies', 'recommendedMovies', 'popularMovies', 'allMovies']:
#         return jsonify({"error": "Invalid source"}), 400

#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute(f"SELECT * FROM {source} WHERE id = %s", (movie_id,))
#     movie = cursor.fetchone()
#     cursor.close()
#     conn.close()

#     if movie:
#         movie_data = format_movie_data(movie)
#         return jsonify(movie_data)
#     else:
#         print(f"Movie with ID {movie_id} not found in {source} table")
#         return jsonify({"error": "Movie not found"}), 404

# # API route to get theater data
# @app.route('/getTheaters', methods=['GET'])
# def get_theaters():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM theaters")
#     theaters = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     theater_list = []
#     for theater in theaters:
#         theater_data = {
#             "id": theater[0],
#             "name": theater[1],
#             "location": theater[2],
#             "show_date": theater[3].strftime('%Y-%m-%d') if isinstance(theater[3], datetime) else theater[3],
#             "address": theater[4]
#         }
#         theater_list.append(theater_data)

#     return jsonify(theater_list)

# @app.route('/submitMessage', methods=['POST'])
# def submit_message():
#     try:
#         data = request.get_json()  # Get the data from the frontend
#         name = data.get('name')
#         email = data.get('email')
#         message = data.get('message')

#         # Ensure all fields are provided
#         if not name or not email or not message:
#             return jsonify({"error": "All fields are required"}), 400

#         # Connect to the database
#         conn = connect_db()
#         if not conn:
#             return jsonify({"error": "Database connection failed"}), 500

#         cursor = conn.cursor()

#         # Insert the message into the contactMessages table
#         query = "INSERT INTO contactMessages (name, email, message) VALUES (%s, %s, %s)"
#         cursor.execute(query, (name, email, message))
#         conn.commit()

#         cursor.close()
#         conn.close()

#         return jsonify({"success": "Message submitted successfully!"})

#     except Exception as e:
#         print(f"Error: {e}")
#         return jsonify({"error": "Internal server error"}), 500
    



# @app.route('/confirmPayment', methods=['POST'])
# def confirm_payment():
#     data = request.get_json()
#     movie_title = data.get('movieTitle')
#     movie_type = data.get('movieType')
#     selected_seats = data.get('selectedSeats')
#     selected_time = data.get('selectedTime')
#     ticket_price = data.get('ticketPrice')

#     # Connect to the database
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500

#     cursor = conn.cursor()

#     # Insert new ticket into the booked_tickets table
#     try:
#         query = """INSERT INTO booked_tickets (movie_title, movie_type, seat_number, show_time, ticket_price, booking_date)
#                    VALUES (%s, %s, %s, %s, %s, %s)"""
#         cursor.execute(query, (
#             movie_title,
#             movie_type,
#             ', '.join(selected_seats),
#             selected_time,
#             ticket_price,
#             datetime.now()  # Store current date and time as booking date
#         ))
#         conn.commit()

#         return jsonify({'success': True})

#     except Exception as e:
#         print(f"Error: {e}")  # Log the error for debugging
#         return jsonify({"error": "Failed to book ticket"}), 500

#     finally:
#         cursor.close()
#         conn.close()


# @app.route('/getBookedTickets', methods=['GET'])
# def get_booked_tickets():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500

#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM booked_tickets ORDER BY booking_date DESC")
#     booked_tickets = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     ticket_list = []
#     for ticket in booked_tickets:
#         ticket_data = {
#             "id": ticket[0],
#             "movie_title": ticket[1],
#             "movie_type": ticket[2],
#             "seat_number": ticket[3],
#             "show_time": ticket[4],
#             "ticket_price": ticket[5],
#             "booking_date": ticket[6].strftime('%Y-%m-%d %H:%M:%S') if isinstance(ticket[6], datetime) else ticket[6],
#         }
#         ticket_list.append(ticket_data)

#     return jsonify(ticket_list)


# # Run the app
# if __name__ == '__main__':
#     app.run(debug=True)






from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector
from datetime import datetime
import logging
import traceback

app = Flask(__name__)
CORS(app)

logging.basicConfig(level=logging.INFO)

# Function to connect to the MySQL database
def connect_db():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='root',
            password='ritesh@7506',
            database='listing_movies'
        )
        return conn
    except mysql.connector.Error as err:
        logging.error(f"Database connection error: {err}")
        return None

# Function to format movie data
def format_movie_data(movie):
    return {
        "id": movie[0],
        "poster_url": movie[1] or 'default-poster.jpg',
        "title": movie[2] or 'No title available',
        "rating": float(movie[3]) if movie[3] is not None else 'N/A',
        "type": movie[4] or 'Type not available',
        "description": movie[5] or 'No description available'
    }

# API route to get all movies data from the `movies` table
@app.route('/getMovies', methods=['GET'])
def get_movies():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM movies")
    listing_movies = cursor.fetchall()
    cursor.close()
    conn.close()

    movie_list = [format_movie_data(movie) for movie in listing_movies]
    return jsonify(movie_list)

# API route to get recommended movies
@app.route('/getRecommendedMovies', methods=['GET'])
def get_recommended_movies():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM recommendedMovies")
    recommended_movies = cursor.fetchall()
    cursor.close()
    conn.close()

    recommended_list = [format_movie_data(movie) for movie in recommended_movies]
    return jsonify(recommended_list)

# API route to get popular movies
@app.route('/getPopularMovies', methods=['GET'])
def get_popular_movies():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM popularMovies")
    popular_movies = cursor.fetchall()
    cursor.close()
    conn.close()

    popular_list = [format_movie_data(movie) for movie in popular_movies]
    return jsonify(popular_list)

# API route to get all movies data from the `allMovies` table
@app.route('/getAllMovies', methods=['GET'])
def get_all_movies():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM allMovies")
    all_movies = cursor.fetchall()
    cursor.close()
    conn.close()

    all_movies_list = [format_movie_data(movie) for movie in all_movies]
    return jsonify(all_movies_list)

# API route to get movie details by ID and source
@app.route('/getMovieDetail', methods=['GET'])
def get_movie_detail():
    movie_id = request.args.get('id')
    source = request.args.get('source', 'allMovies')  # Default to 'allMovies'

    logging.info(f"Received movie_id: {movie_id}, source: {source}")

    if not movie_id:
        return jsonify({"error": "No movie ID provided"}), 400

    if source not in ['movies', 'recommendedMovies', 'popularMovies', 'allMovies']:
        return jsonify({"error": "Invalid source"}), 400

    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM {source} WHERE id = %s", (movie_id,))
    movie = cursor.fetchone()
    cursor.close()
    conn.close()

    if movie:
        movie_data = format_movie_data(movie)
        return jsonify(movie_data)
    else:
        logging.warning(f"Movie with ID {movie_id} not found in {source} table")
        return jsonify({"error": "Movie not found"}), 404

# API route to get theater data
@app.route('/getTheaters', methods=['GET'])
def get_theaters():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM theaters")
    theaters = cursor.fetchall()
    cursor.close()
    conn.close()

    theater_list = []
    for theater in theaters:
        theater_data = {
            "id": theater[0],
            "name": theater[1],
            "location": theater[2],
            "show_date": theater[3].strftime('%Y-%m-%d') if isinstance(theater[3], datetime) else theater[3],
            "address": theater[4]
        }
        theater_list.append(theater_data)

    return jsonify(theater_list)

@app.route('/submitMessage', methods=['POST'])
def submit_message():
    try:
        data = request.get_json()  # Get the data from the frontend
        name = data.get('name')
        email = data.get('email')
        message = data.get('message')

        # Ensure all fields are provided
        if not name or not email or not message:
            return jsonify({"error": "All fields are required"}), 400

        # Connect to the database
        conn = connect_db()
        if not conn:
            return jsonify({"error": "Database connection failed"}), 500

        cursor = conn.cursor()

        # Insert the message into the contactMessages table
        query = "INSERT INTO contactMessages (name, email, message) VALUES (%s, %s, %s)"
        cursor.execute(query, (name, email, message))
        conn.commit()

        cursor.close()
        conn.close()

        return jsonify({"success": "Message submitted successfully!"})

    except Exception as e:
        logging.error(f"Error submitting message: {e}")
        return jsonify({"error": "Internal server error"}), 500
    

import traceback

@app.route('/saveBooking', methods=['POST'])
def save_booking():
    try:
        data = request.get_json()
        movie_title = data.get('movieTitle')
        movie_type = data.get('movieType')
        selected_seats = data.get('selectedSeats')
        selected_time = data.get('selectedTime')

        # Ensure all fields are provided
        if not all([movie_title, movie_type, selected_seats, selected_time]):
            return jsonify({"error": "All fields are required."}), 400

        logging.info(f"Selected seats: {selected_seats}")  # Log selected seats

        conn = connect_db()
        cursor = conn.cursor()

        # Prepare the SQL query with placeholders for selected seats
        placeholders = ', '.join(['%s'] * len(selected_seats))  # Create placeholders for each seat
        query = f"SELECT seat_number FROM booked_tickets WHERE movie_title = %s AND show_time = %s AND seat_number IN ({placeholders})"
        logging.info(f"Executing query: {query} with parameters: {movie_title}, {selected_time}, {selected_seats}")

        cursor.execute(query, (movie_title, selected_time, *selected_seats))  # Unpack the list of seats
        booked_seats = cursor.fetchall()

        # Check for already booked seats
        if booked_seats:
            return jsonify({"error": "Some seats are already booked."}), 409  # Conflict

        # Insert booking details
        for seat in selected_seats:
            cursor.execute("""
                INSERT INTO booked_tickets (movie_title, movie_type, seat_number, show_time, booking_date)
                VALUES (%s, %s, %s, %s, %s)
            """, (movie_title, movie_type, seat, selected_time, datetime.now()))

        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({'success': True})

    except Exception as e:
        logging.error(f"Error booking ticket: {str(e)}")
        logging.error(traceback.format_exc())  # Log full traceback
        return jsonify({"error": "Failed to book ticket."}), 500


@app.route('/getBookedTickets', methods=['GET'])
def get_booked_tickets():
    logging.info("get_booked_tickets called")  # Add this line for debugging
    try:
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM booked_tickets ORDER BY booking_date DESC")
        booked_tickets = cursor.fetchall()

        ticket_list = []
        for ticket in booked_tickets:
            ticket_data = {
                "id": ticket[0],
                "movie_title": ticket[1],
                "movie_type": ticket[2],
                "seat_number": ticket[3],
                "show_time": ticket[4],
                "booking_date": ticket[5].strftime('%Y-%m-%d %H:%M:%S') if ticket[5] else 'N/A'
            }
            ticket_list.append(ticket_data)

        cursor.close()
        conn.close()

        return jsonify(ticket_list)
    except Exception as e:
        logging.error(f"Error fetching booked tickets: {e}")
        return jsonify({"error": "Failed to fetch booked tickets."}), 500



# Run the app
if __name__ == '__main__':
    app.run(debug=True)









