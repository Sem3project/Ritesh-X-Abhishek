CREATE DATABASE  IF NOT EXISTS `listing_movies` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `listing_movies`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: listing_movies
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allmovies`
--

DROP TABLE IF EXISTS `allmovies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `allmovies` (
  `id` int NOT NULL,
  `poster_url` varchar(500) NOT NULL,
  `title` varchar(255) NOT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allmovies`
--

LOCK TABLES `allmovies` WRITE;
/*!40000 ALTER TABLE `allmovies` DISABLE KEYS */;
INSERT INTO `allmovies` VALUES (1,'1899.jpg','1899',6.20,'Action | 2D','When mysterious events change the course of an immigrant ship headed for New York in 1899, a mind-bending riddle unfolds for its bewildered passengers. Watch all you want. Emily Beecham and Andreas Pietschmann star in this drama from the creators of Jantje Friese and Baran bo Odar.'),(2,'civilwar.jpg','Civil War',7.20,'Sci-Fi/Action | 2D','A journey across a dystopian future America, following a team of military-embedded journalists as they race against time to reach DC before rebel factions descend upon the White House.'),(3,'beekeeper.jpg','Beekeeper',8.10,'Sci-Fi/Action | 2D','When his kind-hearted landlady commits suicide after falling victim to a phishing scam, former Beekeeper operative Adam Clay sets out on a brutal campaign for revenge upon those responsible. The Beekeeper was released in the United States by Amazon MGM Studios under the Metro-Goldwyn-Mayer label on January 12, 2024.'),(4,'avengers.jpg','Avengers',8.90,'Sci-Fi | 2D','ENDGAME is set after Thanos catastrophic use of the Infinity Stones randomly wiped out half of Earths population in Avengers Infinity War. Those left behind are desperate to do something -- anything -- to bring back their lost loved ones.'),(5,'ameena.jpg','Ameena',5.40,'Horror | 2D','Summaries. The movie is about the real life story of a girl named Ameena from Hyderabad, India, who is victim of human trafficking. True story of two teenagers, Ameena, 32 years ago and Meena, a young independent girl of today.'),(6,'afraid.jpg','Afraid',6.60,'Horror | 2D','Its plot follows a family whose smart home AI increasingly interjects itself into their lives. Afraid was released in the United States by Sony Pictures Releasing on August 30, 2024. The film received negative reviews from critics and has grossed $10.6 million worldwide.'),(7,'darbar.jpg','Darbar',7.00,'Thriller | 2D','It follows Aaditya Arunasalam (Rajinikanth), the commissioner of Mumbai Police, who sets out to curb the city rampant drug-trafficking and prostitution. When he uncovers a deep controversy linked to an international drug lord, however, he tries to fulfill his secret agenda.'),(8,'deadpool.jpg','Deadpool and Wolverine',6.90,'Action | 2D','Deadpool is offered a place in the Marvel Cinematic Universe by the Time Variance Authority, but instead recruits a variant of Wolverine to save his universe from extinction.'),(9,'extraction2.jpg','Extraction 2',6.20,'Action','Plot. After barely surviving a previous mission in Dhaka, Tyler Rake retires from mercenary work to a cabin in Austria to recuperate. Tyler is later approached by a stranger and asked to rescue Tylers ex-wife Mias sister Ketevan and her two children Sandro and Nina.'),(10,'bhootpolice.jpg','Bhoot Police',5.90,'Comedy | 2D','Plot. Two brothers, Vibhooti Vibhu Vaidya (Saif Ali Khan) and Chiraunji Chiku Vaidya (Arjun Kapoor), run a fake exorcism business, conning people by exploiting their superstitions. They arrive in a Rajasthan village to exorcise a girl, but Vibhooti discovers she faking possession to avoid an arranged marriage.'),(11,'fighter.jpg','Fighter',6.90,'Action | 2D','In Srinagar, Jammu and Kashmir, a terrorist organization led by Azhar Akhtar plans to attack India, targeting the Srinagar Air Force Station base of the Indian Air Force. Group captain Rakesh Rocky Jai Singh is assigned to counter the threat and forms a team called Air Dragons consisting of skilled fighter pilots.'),(12,'devara.jpg','Devara',8.20,'Action | 2D','Set in the 1980s and 1990s, Devara: Part 1 is an epic action saga centered around Devara, a fearless man from a coastal region who embarks on a perilous journey into the treacherous world of the sea to safeguard the lives of his people. Unbeknownst to him, his brother Bhaira is plotting a conspiracy against him.'),(13,'doctorstrange.jpg','Doctor Strange',8.00,'Sci-Fi | 2D','Dr. Stephen Strange (Benedict Cumberbatch) life changes after a car accident robs him of the use of his hands. When traditional medicine fails him, he looks for healing, and hope, in a mysterious enclave.'),(14,'furious.jpg','Forious',7.00,'Sci-Fi | 2D','In the 13th century, an amnesiac soldier vows to get his revenge on the Mongol army that ransacked his village.'),(15,'gadar2.jpg','Gadar 2',7.00,'Action | 2D','When Tara Singh goes missing during a skirmish and is believed to be captured in Pakistan, his son Jeetey sets out to rescue him and enters a labyrinth from which they both must escape at all costs. Gadar II brings back Indias most loved family of Tara, Sakeena and Jeete 22 years after its predecessor.'),(16,'GOAT.jpeg','GOAT',6.00,'Action | 2D','Director Venkat Prabhu sets the tone of his Vijay-starrer GOAT (The Greatest of All Time) right from the very first scene. Its a recovery mission for a covert team of agents led by Gandhi (Vijay) against the villain Rajiv menon'),(17,'housefull.jpg','Housefull',8.00,'Comedy | 2D','Aarush, is a jinxed loser who stays with his friend, Bob and his wife, Hetal, both working at a casino owned by Mr. Kishore Samtani. Although at first Hetal is displeased with Aarushs presence, he proves to be a kind- hearted man looking for family.'),(18,'inception.jpg','Inception',5.20,'Sci-Fi | 2D','Dom Cobb (Leonardo DiCaprio) is a thief with the rare ability to enter peoples dreams and steal their secrets from their subconscious. His skill has made him a hot commodity in the world of corporate espionage but has also cost him everything he loves.'),(19,'ismartshankar.jpg','iSmart',6.20,'Action | 2D','Ismart Shankar is a crazy contract killer who murders a high profile politician, Kasi Viswanath. Cops start chasing him and Shankar escapes with his girlfriend Chandni. On the other hand, Arun is a cop who is handling the same case. Just when he is about to nab the actual culprit behind the murder, he gets killed.'),(20,'joker.jpg','Joker',8.20,'Thriller | 2D','Arthur wears two masks -- the one he paints for his day job as a clown, and the guise he projects in a futile attempt to feel like he part of the world around him. Isolated, bullied and disregarded by society, Fleck begins a slow descent into madness as he transforms into the criminal mastermind known as the Joker.'),(21,'wednesday.jpg','Wednesday',5.00,'Horror | 2D','A 2008 Indian Hindi-language action thriller film about a police commissioner who confronts an anonymous caller who threatens to detonate bombs in Mumbai. The film stars Naseeruddin Shah and Anupam Kher, and was written and directed by Neeraj'),(22,'tanhaji.jpg','Tanhaji',7.20,'Mystry | 2D','Set in the 17th century, it revolves around Tanaji attempts to recapture the Kondhana fortress once it passes on to Mughal emperor Aurangzeb who transfers its control to his trusted guard Udaybhan Singh Rathore. The film was originally named Tanaji: The Unsung Warrior but the name was later changed to Tanhaji.'),(23,'ravanasura.jpg','Ravanasura',6.20,'Action | 2D','Ravindra is a junior lawyer working under his ex-girlfriend Kanaka Mahalakshmi, who mostly goofs up the cases. He is also friends with Srikanth, Kanaka Mahalakshm husband. One day, Harika Talwar, Vijay daughter and R&D head of Syncox Pharma, asks Ravindra to prove her father innocence.'),(24,'sweethome.jpg','Sweet',8.20,'Sci-Fi | 2D','As humans turn into savage monsters and wreak terror, one troubled teen and his apartment neighbors fight to survive — and to hold on to their humanity.'),(25,'pathaan.jpg','Pathaan',7.20,'Action | 2D','Indian RAW agent Pathaan (Shah Rukh Khan) gets to know of a major impending attack against India, mounted by a mercenary group led by the ruthless enigma Jim (John Abraham), who has a history of his own.'),(26,'msdhoni.jpg','MS Dhoni',9.20,'Biography | 2D','The Untold Story is a 2016 Indian Hindi-language biographical sports drama film directed and co-written by Neeraj Pandey. It is based on the life of former Test, ODI and T20I captain of the Indian national cricket team, Mahendra Singh Dhoni.'),(27,'martian.jpg','Martian',7.60,'Sci-Fi | 2D','When astronauts blast off from the planet Mars, they leave behind Mark Watney (Matt Damon), presumed dead after a fierce storm. With only a meager amount of supplies, the stranded visitor must utilize his wits and spirit to find a way to survive on the hostile planet.'),(28,'lagaan.jpg','Lagaan',8.60,'Action | 2D','Synopsis The year is 1893 and India is under British occupation. In a small village, the tyrannical Captain Russell (Paul Blackthorne) has imposed an unprecedented land tax on its citizens. Outraged, Bhuvan (Aamir Khan), a rebellious farmer, rallies the villagers to publicly oppose the tax.'),(29,'kalki.jpg','Kalki',7.60,'Sci-Fi | 2D','Inspired by Hindu mythology, it is the first instalment in a planned Kalki Cinematic Universe. Set in a post-apocalyptic world in the year 2898 AD, the film follows a select group who are on a mission to save lab subject SUM-80s unborn child, Kalki.'),(30,'afraid.jpg','Afraid',6.60,'Horror | 2D','Its plot follows a family whose smart home AI increasingly interjects itself into their lives. Afraid was released in the United States by Sony Pictures Releasing on August 30, 2024. The film received negative reviews from critics and has grossed $10.6 million worldwide.');
/*!40000 ALTER TABLE `allmovies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booked_tickets`
--

DROP TABLE IF EXISTS `booked_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booked_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `movie_title` varchar(255) DEFAULT NULL,
  `movie_type` varchar(50) DEFAULT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `show_time` varchar(10) DEFAULT NULL,
  `ticket_price` decimal(10,2) DEFAULT NULL,
  `booking_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_movie_seat_show` (`movie_title`,`seat_number`,`show_time`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booked_tickets`
--

LOCK TABLES `booked_tickets` WRITE;
/*!40000 ALTER TABLE `booked_tickets` DISABLE KEYS */;
INSERT INTO `booked_tickets` VALUES (28,'Rayaan','Action | 2D','A5','10:00 AM',NULL,'2024-09-21 18:05:52'),(29,'Rayaan','Action | 2D','A1','1:00 PM',NULL,'2024-09-21 18:06:04'),(30,'Rayaan','Action | 2D','A2','1:00 PM',NULL,'2024-09-21 18:06:04'),(31,'Inception','Sci-Fi | 2D','A8','10:00 AM',NULL,'2024-09-21 18:07:36'),(32,'Inception','Sci-Fi | 2D','A9','10:00 AM',NULL,'2024-09-21 18:07:36'),(33,'Inception','Sci-Fi | 2D','A10','10:00 AM',NULL,'2024-09-21 18:07:36'),(34,'Inception','Sci-Fi | 2D','A11','10:00 AM',NULL,'2024-09-21 18:07:36'),(35,'Inception','Sci-Fi | 2D','A2','10:00 AM',NULL,'2024-09-21 18:08:36'),(36,'Forious','Sci-Fi | 2D','A12','10:00 AM',NULL,'2024-09-21 18:08:53'),(37,'Darbar','Thriller | 2D','A12','10:00 AM',NULL,'2024-09-21 18:55:59'),(38,'Kalki','Sci-Fi | 2D','A12','1:00 PM',NULL,'2024-09-21 18:57:23'),(39,'Extraction 2','Action','A9','10:00 AM',NULL,'2024-09-21 19:08:39');
/*!40000 ALTER TABLE `booked_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactmessages`
--

DROP TABLE IF EXISTS `contactmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contactmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactmessages`
--

LOCK TABLES `contactmessages` WRITE;
/*!40000 ALTER TABLE `contactmessages` DISABLE KEYS */;
INSERT INTO `contactmessages` VALUES (1,'Ritesh Vishwakarma','riteshvishwakarma7506@gmail.com','sdfgag','2024-09-20 12:35:06'),(2,'Ritesh Vishwakarma','riteshvishwakarma7506@gmail.com','hi my name is ritesh\n','2024-09-21 02:57:18'),(3,'Ritesh Vishwakarma','riteshvishwakarma7506@gmail.com','sdgsg','2024-09-21 19:05:57');
/*!40000 ALTER TABLE `contactmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies` (
  `id` int NOT NULL,
  `poster_url` text,
  `title` text,
  `rating` decimal(3,1) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES (1,'stree2.jpg','Stree 2',8.5,'Comedy','While Stree (2018) revolved around a female ghost, who was wronged in her mortal life, its sequel focuses on a headless villain called Sarkata. Stree 2 follows Sarkata abducting women with an independent voice. The film also stars Pankaj Tripathi, Abhishek Banerjee and Aparshakti Khurana'),(2,'vedda.jpg','Vedda',7.0,'Action | 2D','Vedaa centers on a Dalit girl who is being abused and tortured by the upper caste. She wants to learn boxing to protect herself and her family. Abhimanyu Kanwar joins a college as an Assistant Boxing Coach in his wifes city. His wife Raashi was killed in Kashmir by a terrorist.'),(3,'tumbbad.jpg','Tumbbad',8.6,'Horror/Mystry | 2D','Set in a Maharashtra village, Tumbbad explores Vinayak Raos (Sohum) descent into greed and obsession as he seeks out a mythical treasure guarded by the malevolent entity Hastar.'),(4,'thalangan.jpg','Thalangan',8.2,'Action | 2D','The film stars Vikram in five roles alongside Parvathy Thiruvothu, Malavika Mohanan, Daniel Caltagirone, Pasupathy and Hari Krishnan. During the British Raj era, a fierce tribal leader sets out to stop an apparent sorceress, after earning her wrath when assisting a British general in tracing gold in their village.'),(5,'rayaan.jpg','Rayaan',9.0,'Action | 2D','In the film, a fast-food hotel owner in North Chennai struggles to protect his family when they inadvertently get muddled in a war between two rival gangs resulting in unforeseen circumstances.'),(6,'kalki.jpg','Kalki',8.9,'Sci-Fi | 2D','Inspired by Hindu mythology, it is the first instalment in a planned Kalki Cinematic Universe. Set in a post-apocalyptic world in the year 2898 AD, the film follows a select group who are on a mission to save lab subject SUM-80s unborn child, Kalki.');
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `popularmovies`
--

DROP TABLE IF EXISTS `popularmovies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `popularmovies` (
  `id` int NOT NULL,
  `poster_url` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `popularmovies`
--

LOCK TABLES `popularmovies` WRITE;
/*!40000 ALTER TABLE `popularmovies` DISABLE KEYS */;
INSERT INTO `popularmovies` VALUES (1,'1899.jpg','1899',7.6,'Thriller | 2D','When mysterious events change the course of an immigrant ship headed for New York in 1899, a mind-bending riddle unfolds for its bewildered passengers. Watch all you want. Emily Beecham and Andreas Pietschmann star in this drama from the creators of Jantje Friese and Baran bo Odar.'),(2,'afraid.jpg','Afraid',6.6,'Horror | 2D','Its plot follows a family whose smart home AI increasingly interjects itself into their lives. Afraid was released in the United States by Sony Pictures Releasing on August 30, 2024. The film received negative reviews from critics and has grossed $10.6 million worldwide.'),(3,'ameena.jpg','Ameena',5.4,'Horror | 2D','Summaries. The movie is about the real life story of a girl named Ameena from Hyderabad, India, who is victim of human trafficking. True story of two teenagers, Ameena, 32 years ago and Meena, a young independent girl of today.'),(4,'avengers.jpg','Avengers',8.9,'Sci-Fi | 2D','ENDGAME is set after Thanos catastrophic use of the Infinity Stones randomly wiped out half of Earths population in Avengers Infinity War. Those left behind are desperate to do something -- anything -- to bring back their lost loved ones.'),(5,'beekeeper.jpg','Beekeeper',8.1,'Sci-Fi/Action | 2D','When his kind-hearted landlady commits suicide after falling victim to a phishing scam, former Beekeeper operative Adam Clay sets out on a brutal campaign for revenge upon those responsible. The Beekeeper was released in the United States by Amazon MGM Studios under the Metro-Goldwyn-Mayer label on January 12, 2024.'),(6,'civilwar.jpg','Civil War',7.2,'Sci-Fi/Action | 2D','A journey across a dystopian future America, following a team of military-embedded journalists as they race against time to reach DC before rebel factions descend upon the White House.');
/*!40000 ALTER TABLE `popularmovies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendedmovies`
--

DROP TABLE IF EXISTS `recommendedmovies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendedmovies` (
  `id` int NOT NULL,
  `poster_url` text,
  `title` text,
  `rating` decimal(3,1) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendedmovies`
--

LOCK TABLES `recommendedmovies` WRITE;
/*!40000 ALTER TABLE `recommendedmovies` DISABLE KEYS */;
INSERT INTO `recommendedmovies` VALUES (1,'avtarOG.jpg','Avtar',9.1,'Sci-Fi | 2D','A paraplegic Marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home. A paraplegic Marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home.'),(2,'fighter.jpg','Fighter',7.5,'Action | 2D','In Srinagar, Jammu and Kashmir, a terrorist organization led by Azhar Akhtar plans to attack India, targeting the Srinagar Air Force Station base of the Indian Air Force. Group captain Rakesh Rocky Jai Singh is assigned to counter the threat and forms a team called Air Dragons consisting of skilled fighter pilots.'),(3,'devara.jpg','Devara',8.5,'Mystery | 2D','Set in the 1980s and 1990s, Devara: Part 1 is an epic action saga centered around Devara, a fearless man from a coastal region who embarks on a perilous journey into the treacherous world of the sea to safeguard the lives of his people. Unbeknownst to him, his brother Bhaira is plotting a conspiracy against him.'),(4,'extraction2.jpg','Extraction 2',6.2,'Action','Plot. After barely surviving a previous mission in Dhaka, Tyler Rake retires from mercenary work to a cabin in Austria to recuperate. Tyler is later approached by a stranger and asked to rescue Tylers ex-wife Mias sister Ketevan and her two children Sandro and Nina.'),(5,'deadpool.jpg','Deadpool and Wolverine',6.9,'Action | 2D','Deadpool is offered a place in the Marvel Cinematic Universe by the Time Variance Authority, but instead recruits a variant of Wolverine to save his universe from extinction.'),(6,'darbar.jpg','Darbar',7.0,'Thriller | 2D','It follows Aaditya Arunasalam (Rajinikanth), the commissioner of Mumbai Police, who sets out to curb the city rampant drug-trafficking and prostitution. When he uncovers a deep controversy linked to an international drug lord, however, he tries to fulfill his secret agenda.');
/*!40000 ALTER TABLE `recommendedmovies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theaters`
--

DROP TABLE IF EXISTS `theaters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theaters` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(500) DEFAULT NULL,
  `show_date` date DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theaters`
--

LOCK TABLES `theaters` WRITE;
/*!40000 ALTER TABLE `theaters` DISABLE KEYS */;
INSERT INTO `theaters` VALUES (1,'Cinemax- PVR Cinemas','Malad','2024-09-17','3rd floor, Infiniti Mall Malad, 2, New Link Rd, Malad, Mindspace, Malad West, Mumbai,'),(2,'Movie time cinema','Malad','2024-09-17','Sneh Sadan Welfare Society, near movie time theatre, Khandelwal Layout, Evershine Nagar, Malad West, Mumbai, Maharashtra 400064'),(3,'Inox Megaplex','Malad','2024-09-17','New Link Rd, Malad, Malad West, Mumbai, Maharashtra 400064'),(4,'PVR Growels','Kandivali','2024-09-17','Western Express Hwy, Kandivali, Akurli Industry Estate, Kandivali East, Mumbai,Maharashtra 400101'),(5,'Inox','Kandivali','2024-09-18','Raghuleela Mega Mall, INOX Leisure Ltd., 2nd Floor, Swami Vivekananda Rd, Kandivali West, Mumbai, Maharashtra 400067'),(6,'PVR Cinemas','Kandivali','2024-09-19','Swami Vivekananda Rd, Majithia Nagar, Goraswadi, Kandivali West, Mumbai, Maharashtra 400067'),(7,'Carnival Cinemas','Borivali','2024-09-17','Carvinal Cinemas Annex Mall, near Prithvi Enclave, Siddharth Nagar, Borivali East, Mumbai, Maharashtra 400066'),(8,'Ajanta Cinex','Borivali','2024-09-18','4th Floor, Ajanta Cinex Cinema, Ajanta Square Mall, Lokmanya Tilak Rd, Sundar Nagar, Borivali, Mumbai, Maharashtra 400092'),(9,'Maxus Cinemas','Borivali','2024-09-19','Zoom Plaza Mall, 35, Lokmanya Tilak Rd, Gorai 2, Borivali, Mumbai, Maharashtra 400092'),(10,'Inox Thakur Mall','Dahisar','2024-09-17','3rd Floor, Thakur Mall, Dahisar East, near Dahisar Toll Naka, Ketkipada, Mira Road East,  Mumbai, Maharashtra 401107'),(11,'Movie Time','Dahisar','2024-09-18','Old Rajeshri Cinema Building, Maratha Colony Rd, Maratha Colony, Dahisar East, Mumbai,  Maharashtra 400068'),(12,'Movietime: The Hub Mall','Goregaon','2024-09-17','Police Station, 3rd Floor, The Hub Mall Western Express Highway Nirlon Compound, Near, Goregaon, Mumbai, Maharashtra 400063'),(13,'PVR ICON- Oberoi','Goregaon','2024-09-18','Western Express Hwy, Yashodham, Goregaon, Mumbai, Maharashtra 400063'),(14,'Miraj Cinema','Goregaon','2024-09-19','Goregaon Railway Foot Over Bridge 1, Peru Baug, Jay Prakash Nagar, Goregaon, Mumbai,  Maharashtra 400063'),(15,'24 Karat Range Of Mobile','Jogeshwari','2024-09-17','Sani Apartment, A/101, Swami Vivekananda Rd, above Bostan Hotel, NESCO, Jogeshwari West, Mumbai, Maharashtra 400102'),(16,'PVR ICON Infiniti Andheri','Andheri','2024-09-17','3rd floor, Infinity Mall, New Link Rd, Phase D, Shastri Nagar, Versova, Mumbai, Maharashtra  400036'),(17,'PVR Cinemas','Andheri','2024-09-18','No.127, Andheri- Kurla Rd, Opp Acme Plaza, Dr. Charatsingh Colony, S B Singh Colony,  Chakala, Andheri East, Mumbai, Maharashtra 400059'),(18,'Cinepolis','Andheri','2024-09-19','Fun Republic Mall, next to Yash Raj Films Private Limited, Industrial Area, Andheri West,  Mumbai, Maharashtra 400053'),(19,'PVR Le Reve Bandra','Bandra','2024-09-17','Corner of Hill Road, and, Waterfield Road, Bandra West, Mumbai, Maharashtra 400050'),(20,'G7 Gaiety Galaxy Movie Theatre','Bandra','2024-09-18','3R6Q+HF4, Tata Blocks, 30th Rd, Bandra west, Mumbai 400050'),(21,'Movietime: Suburbia','Bandra','2024-09-19','Junction of S.V. Road and Linking Road, behind SHOPPERS STOP, Bandra West, Mumbai, Maharashtra 400050'),(22,'Plaza Cinema','Dadar','2024-09-20','N C. Kelkar Marg, Dadar West, Dadar, Mumbai, Maharashtra 400028'),(23,'Gold Cinema','Dadar','2024-09-21',' Dr. Ambedkar Road, Naigaon, Dadar (East), Dr Baba Saheb  Ambedkar Rd, Mumbai, Maharashtra 400014'),(24,' Hindmata Cinema ','Dadar','2024-09-22',' Dr. Ambedkar Road, Naigaon, Dadar (East), Dr Baba Saheb  Ambedkar Rd, Mumbai, Maharashtra 400014'),(25,'Chitra Cinema','Dadar','2024-09-20','Dr Baba Saheb Ambedkar Rd, Dadar East, Dadar, Mumbai, Maharashtra 400014'),(26,'Maratha Mandir Theatre','Mumbai Center','2024-09-20','M MMarg, RBI Staff Colony, Mumbai Central, Mumbai, Maharashtra 400008'),(27,'Central Plaza','Mumbai Center','2024-09-21','R R Roy Marg, Girgaon Chowpatty, Mumbai,  Maharashtra 400004'),(28,'Metro INOX Cinema','Marin Lines','2024-09-20','Mahatma Gandhi Road, Dhobi Talao, New Marine Lines, Junction, Mumbai, Maharashtra 400020'),(29,'Inox Laserplex','Churchgate','2024-09-20','CR2, 2nd Floor, Nariman Point, Mumbai, Maharashtra 400021'),(30,'Eros IMAX, Mumbai','Churchgate','2024-09-21','Cambata Building, 42, Maharshi Karve Rd, Churchgate, Mumbai, Maharashtra 400020'),(31,'MovieMax Cinema','Mira-Bhayandar','2024-09-20','Mira Road East, Mira Bhayandar, Maharashtra 401107'),(32,'Rassaz Multiplex','Mira-Bhayandar','2024-09-21','Bharti Nagar, Mira Road East, Mira Bhayandar, Maharashtra 401107'),(33,'Nityasai finance','Mira-Bhayandar','2024-09-22','Beverly Park Rd, Vagad Nagar, Beverly Park, Mira Road East, Mira Bhayandar, Maharashtra 401107'),(34,'Fun Fiesta Multiplex','Nallasopara','2024-09-20','Complex, Sriprastha, Nalasopara West, Nala Sopara, Maharashtra 401203'),(35,'PVR Cinema: The Capital Mall','Nallasopara','2024-09-21','Capital Mall, Nallasopara east, Mumbai 401209 '),(36,'Movie Max Cinema','Virar','2024-09-20',' 103, Chandansar Rd, opposite hdil, Chandansar, Vasai, Virar, Maharashtra 401305'),(37,'Woodland Cinemas','Virar','2024-09-21','Woodland Cinemas, Chhatrapati Shivaji Road, Agashi Rd, Virar West, Virar, Maharashtra 401303'),(38,'Rockstar Nova Cinemaz','Virar','2024-09-22','Ladku plaza, Agashi Rd, olanda naka, Bolinj, Virar West, Virar, Maharashtra 401301');
/*!40000 ALTER TABLE `theaters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-22  0:46:09
