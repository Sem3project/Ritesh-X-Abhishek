CREATE DATABASE  IF NOT EXISTS `listing_movies` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `listing_movies`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: listing_movies
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allmovies`
--

DROP TABLE IF EXISTS `allmovies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `allmovies` (
  `id` int NOT NULL,
  `poster_url` varchar(500) NOT NULL,
  `title` varchar(255) NOT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allmovies`
--

LOCK TABLES `allmovies` WRITE;
/*!40000 ALTER TABLE `allmovies` DISABLE KEYS */;
INSERT INTO `allmovies` VALUES (1,'img1.jpg','A',8.50,'Action','An action-packed adventure.'),(2,'img1.jpg','B',8.50,'Action','An action-packed adventure.'),(3,'img1.jpg','C',8.50,'Action','An action-packed adventure.'),(4,'img1.jpg','D',8.50,'Action','An action-packed adventure.'),(5,'img1.jpg','E',8.50,'Action','An action-packed adventure.'),(6,'img1.jpg','F',8.50,'Action','An action-packed adventure.'),(7,'img1.jpg','G',8.50,'Action','An action-packed adventure.'),(8,'img1.jpg','H',8.50,'Action','An action-packed adventure.'),(9,'img1.jpg','I',8.50,'Action','An action-packed adventure.'),(10,'img1.jpg','J',8.50,'Action','An action-packed adventure.'),(11,'img1.jpg','K',8.50,'Action','An action-packed adventure.'),(12,'img1.jpg','L',8.50,'Action','An action-packed adventure.'),(13,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(14,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(15,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(16,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(17,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(18,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(19,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(20,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(21,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(22,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(23,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(24,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(25,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(26,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(27,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(28,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(29,'img1.jpg','M',8.50,'Action','An action-packed adventure.'),(30,'img1.jpg','M',8.50,'Action','An action-packed adventure.');
/*!40000 ALTER TABLE `allmovies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies` (
  `id` int NOT NULL,
  `poster_url` text,
  `title` text,
  `rating` decimal(3,1) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES (1,'img1.jpg','Stree 2',9.0,'Action | Hindi | 2D','An action-packed movie.'),(2,'img1.jpg','Vedda',6.0,'Action | Hindi | 2D','An action-packed movie.'),(3,'img1.jpg','MBBS',8.0,'Action | Hindi | 2D','An action-packed movie.'),(4,'img1.jpg','MBBS 2',8.5,'Action | Hindi | 2D','An action-packed movie.'),(5,'img1.jpg','Leo',8.5,'Action | Hindi | 2D','An action-packed movie.'),(6,'img1.jpg','Pushpa 2',7.5,'Action | Hindi | 2D','An action-packed movie.');
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `popularmovies`
--

DROP TABLE IF EXISTS `popularmovies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `popularmovies` (
  `id` int NOT NULL,
  `poster_url` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `popularmovies`
--

LOCK TABLES `popularmovies` WRITE;
/*!40000 ALTER TABLE `popularmovies` DISABLE KEYS */;
INSERT INTO `popularmovies` VALUES (1,'img1.jpg','Ritesh Ki Jang',8.5,'Action | Hindi | 2D','A action comedy and movie.'),(2,'img1.jpg','Raja Ritesh',8.5,'Action | Hindi | 2D','A action comedy and movie.'),(3,'img1.jpg','RRR',8.5,'Action | Hindi | 2D','A action comedy and movie.'),(4,'img1.jpg','King Ritesh',8.5,'Action | Hindi | 2D','A action comedy and movie.'),(5,'img1.jpg','Ritesh',8.5,'Action | Hindi | 2D','A action comedy and movie.'),(6,'img1.jpg','Ritesh is Boss',8.5,'Action | Hindi | 2D','A action comedy and movie.');
/*!40000 ALTER TABLE `popularmovies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendedmovies`
--

DROP TABLE IF EXISTS `recommendedmovies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendedmovies` (
  `id` int NOT NULL,
  `poster_url` text,
  `title` text,
  `rating` decimal(3,1) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendedmovies`
--

LOCK TABLES `recommendedmovies` WRITE;
/*!40000 ALTER TABLE `recommendedmovies` DISABLE KEYS */;
INSERT INTO `recommendedmovies` VALUES (1,'img2.jpg','Goat',8.7,'Action | Hindi | 2D','This is a description of the movie.'),(2,'img2.jpg','Rayaan',8.7,'Action | Hindi | 2D','This is a description of the movie.'),(3,'img2.jpg','Dhanush',8.7,'Action | Hindi | 2D','This is a description of the movie.'),(4,'img2.jpg','Akshay',8.7,'Action | Hindi | 2D','This is a description of the movie.'),(5,'img2.jpg','Salman',8.7,'Action | Hindi | 2D','This is a description of the movie.'),(6,'img2.jpg','Sharukh',8.7,'Action | Hindi | 2D','This is a description of the movie.');
/*!40000 ALTER TABLE `recommendedmovies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theaters`
--

DROP TABLE IF EXISTS `theaters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theaters` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(500) DEFAULT NULL,
  `show_date` date DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theaters`
--

LOCK TABLES `theaters` WRITE;
/*!40000 ALTER TABLE `theaters` DISABLE KEYS */;
INSERT INTO `theaters` VALUES (1,'Cinemax- PVR Cinemas','Malad','2024-09-17','3rd floor, Infiniti Mall Malad, 2, New Link Rd, Malad, Mindspace, Malad West, Mumbai,'),(2,'Movie time cinema','Malad','2024-09-17','Sneh Sadan Welfare Society, near movie time theatre, Khandelwal Layout, Evershine Nagar, Malad West, Mumbai, Maharashtra 400064'),(3,'Inox Megaplex','Malad','2024-09-17','New Link Rd, Malad, Malad West, Mumbai, Maharashtra 400064'),(4,'PVR Growels','Kandivali','2024-09-17','Western Express Hwy, Kandivali, Akurli Industry Estate, Kandivali East, Mumbai,Maharashtra 400101'),(5,'Inox','Kandivali','2024-09-18','Raghuleela Mega Mall, INOX Leisure Ltd., 2nd Floor, Swami Vivekananda Rd, Kandivali West, Mumbai, Maharashtra 400067'),(6,'PVR Cinemas','Kandivali','2024-09-19','Swami Vivekananda Rd, Majithia Nagar, Goraswadi, Kandivali West, Mumbai, Maharashtra 400067'),(7,'Carnival Cinemas','Borivali','2024-09-17','Carvinal Cinemas Annex Mall, near Prithvi Enclave, Siddharth Nagar, Borivali East, Mumbai, Maharashtra 400066'),(8,'Ajanta Cinex','Borivali','2024-09-18','4th Floor, Ajanta Cinex Cinema, Ajanta Square Mall, Lokmanya Tilak Rd, Sundar Nagar, Borivali, Mumbai, Maharashtra 400092'),(9,'Maxus Cinemas','Borivali','2024-09-19','Zoom Plaza Mall, 35, Lokmanya Tilak Rd, Gorai 2, Borivali, Mumbai, Maharashtra 400092'),(10,'Inox Thakur Mall','Dahisar','2024-09-17','3rd Floor, Thakur Mall, Dahisar East, near Dahisar Toll Naka, Ketkipada, Mira Road East,  Mumbai, Maharashtra 401107'),(11,'Movie Time','Dahisar','2024-09-18','Old Rajeshri Cinema Building, Maratha Colony Rd, Maratha Colony, Dahisar East, Mumbai,  Maharashtra 400068'),(12,'Movietime: The Hub Mall','Goregaon','2024-09-17','Police Station, 3rd Floor, The Hub Mall Western Express Highway Nirlon Compound, Near, Goregaon, Mumbai, Maharashtra 400063'),(13,'PVR ICON- Oberoi','Goregaon','2024-09-18','Western Express Hwy, Yashodham, Goregaon, Mumbai, Maharashtra 400063'),(14,'Miraj Cinema','Goregaon','2024-09-19','Goregaon Railway Foot Over Bridge 1, Peru Baug, Jay Prakash Nagar, Goregaon, Mumbai,  Maharashtra 400063'),(15,'24 Karat Range Of Mobile','Jogeshwari','2024-09-17','Sani Apartment, A/101, Swami Vivekananda Rd, above Bostan Hotel, NESCO, Jogeshwari West, Mumbai, Maharashtra 400102'),(16,'PVR ICON Infiniti Andheri','Andheri','2024-09-17','3rd floor, Infinity Mall, New Link Rd, Phase D, Shastri Nagar, Versova, Mumbai, Maharashtra  400036'),(17,'PVR Cinemas','Andheri','2024-09-18','No.127, Andheri- Kurla Rd, Opp Acme Plaza, Dr. Charatsingh Colony, S B Singh Colony,  Chakala, Andheri East, Mumbai, Maharashtra 400059'),(18,'Cinepolis','Andheri','2024-09-19','Fun Republic Mall, next to Yash Raj Films Private Limited, Industrial Area, Andheri West,  Mumbai, Maharashtra 400053'),(19,'PVR Le Reve Bandra','Bandra','2024-09-17','Corner of Hill Road, and, Waterfield Road, Bandra West, Mumbai, Maharashtra 400050'),(20,'G7 Gaiety Galaxy Movie Theatre','Bandra','2024-09-18','3R6Q+HF4, Tata Blocks, 30th Rd, Bandra west, Mumbai 400050'),(21,'Movietime: Suburbia','Bandra','2024-09-19','Junction of S.V. Road and Linking Road, behind SHOPPERS STOP, Bandra West, Mumbai, Maharashtra 400050'),(22,'Plaza Cinema','Dadar','2024-09-20','N C. Kelkar Marg, Dadar West, Dadar, Mumbai, Maharashtra 400028'),(23,'Gold Cinema','Dadar','2024-09-21',' Dr. Ambedkar Road, Naigaon, Dadar (East), Dr Baba Saheb  Ambedkar Rd, Mumbai, Maharashtra 400014'),(24,' Hindmata Cinema ','Dadar','2024-09-22',' Dr. Ambedkar Road, Naigaon, Dadar (East), Dr Baba Saheb  Ambedkar Rd, Mumbai, Maharashtra 400014'),(25,'Chitra Cinema','Dadar','2024-09-20','Dr Baba Saheb Ambedkar Rd, Dadar East, Dadar, Mumbai, Maharashtra 400014'),(26,'Maratha Mandir Theatre','Mumbai Center','2024-09-20','M MMarg, RBI Staff Colony, Mumbai Central, Mumbai, Maharashtra 400008'),(27,'Central Plaza','Mumbai Center','2024-09-21','R R Roy Marg, Girgaon Chowpatty, Mumbai,  Maharashtra 400004'),(28,'Metro INOX Cinema','Marin Lines','2024-09-20','Mahatma Gandhi Road, Dhobi Talao, New Marine Lines, Junction, Mumbai, Maharashtra 400020'),(29,'Inox Laserplex','Churchgate','2024-09-20','CR2, 2nd Floor, Nariman Point, Mumbai, Maharashtra 400021'),(30,'Eros IMAX, Mumbai','Churchgate','2024-09-21','Cambata Building, 42, Maharshi Karve Rd, Churchgate, Mumbai, Maharashtra 400020'),(31,'MovieMax Cinema','Mira-Bhayandar','2024-09-20','Mira Road East, Mira Bhayandar, Maharashtra 401107'),(32,'Rassaz Multiplex','Mira-Bhayandar','2024-09-21','Bharti Nagar, Mira Road East, Mira Bhayandar, Maharashtra 401107'),(33,'Nityasai finance','Mira-Bhayandar','2024-09-22','Beverly Park Rd, Vagad Nagar, Beverly Park, Mira Road East, Mira Bhayandar, Maharashtra 401107'),(34,'Fun Fiesta Multiplex','Nallasopara','2024-09-20','Complex, Sriprastha, Nalasopara West, Nala Sopara, Maharashtra 401203'),(35,'PVR Cinema: The Capital Mall','Nallasopara','2024-09-21','Capital Mall, Nallasopara east, Mumbai 401209 '),(36,'Movie Max Cinema','Virar','2024-09-20',' 103, Chandansar Rd, opposite hdil, Chandansar, Vasai, Virar, Maharashtra 401305'),(37,'Woodland Cinemas','Virar','2024-09-21','Woodland Cinemas, Chhatrapati Shivaji Road, Agashi Rd, Virar West, Virar, Maharashtra 401303'),(38,'Rockstar Nova Cinemaz','Virar','2024-09-22','Ladku plaza, Agashi Rd, olanda naka, Bolinj, Virar West, Virar, Maharashtra 401301');
/*!40000 ALTER TABLE `theaters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-18 20:47:40
