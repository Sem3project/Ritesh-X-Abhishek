

# from flask import Flask, jsonify, request
# from flask_cors import CORS
# import mysql.connector
# from datetime import datetime  # Import datetime

# app = Flask(__name__)
# CORS(app)

# # Function to connect to the MySQL database
# def connect_db():
#     try:
#         conn = mysql.connector.connect(
#             host='localhost',
#             user='root',
#             password='ritesh@7506',
#             database='listing_movies'
#         )
#         return conn
#     except mysql.connector.Error as err:
#         print(f"Error: {err}")
#         return None

# # API route to get all movies data from the `movies` table
# @app.route('/getMovies', methods=['GET'])
# def get_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM movies")
#     listing_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     movie_list = []
#     for movie in listing_movies:
#         movie_data = {
#             "id": movie[0],
#             "poster_url": movie[1],
#             "title": movie[2],
#             "rating": float(movie[3]),
#             "type": movie[4],
#             "description": movie[5]
#         }
#         movie_list.append(movie_data)

#     return jsonify(movie_list)

# # API route to get recommended movies
# @app.route('/getRecommendedMovies', methods=['GET'])
# def get_recommended_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM recommendedMovies")
#     recommended_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     recommended_list = []
#     for movie in recommended_movies:
#         movie_data = {
#             "id": movie[0],
#             "poster_url": movie[1],
#             "title": movie[2],
#             "rating": float(movie[3]),
#             "type": movie[4],
#             "description": movie[5]
#         }
#         recommended_list.append(movie_data)

#     return jsonify(recommended_list)

# # API route to get popular movies
# @app.route('/getPopularMovies', methods=['GET'])
# def get_popular_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM popularMovies")
#     popular_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     popular_list = []
#     for movie in popular_movies:
#         movie_data = {
#             "id": movie[0],
#             "poster_url": movie[1],
#             "title": movie[2],
#             "rating": float(movie[3]),
#             "type": movie[4],
#             "description": movie[5]
#         }
#         popular_list.append(movie_data)

#     return jsonify(popular_list)

# # API route to get all movies data from the `allMovies` table
# @app.route('/getAllMovies', methods=['GET'])
# def get_all_movies():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM allMovies")
#     all_movies = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     all_movies_list = []
#     for movie in all_movies:
#         movie_data = {
#             "id": movie[0],
#             "poster_url": movie[1],
#             "title": movie[2],
#             "rating": float(movie[3]),
#             "type": movie[4],
#             "description": movie[5]
#         }
#         all_movies_list.append(movie_data)

#     return jsonify(all_movies_list)

# # API route to get movie details by ID and source
# @app.route('/getMovieDetail', methods=['GET'])
# def get_movie_detail():
#     movie_id = request.args.get('id')
#     source = request.args.get('source', 'movies')  # Default to 'movies'

#     if source not in ['movies', 'recommendedMovies', 'popularMovies', 'allMovies']:
#         return jsonify({"error": "Invalid source"}), 400

#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute(f"SELECT * FROM {source} WHERE id = %s", (movie_id,))
#     movie = cursor.fetchone()
#     cursor.close()
#     conn.close()

#     if movie:
#         movie_data = {
#             "id": movie[0],
#             "poster_url": movie[1],
#             "title": movie[2],
#             "rating": float(movie[3]),
#             "type": movie[4],
#             "description": movie[5]
#         }
#         return jsonify(movie_data)
#     else:
#         return jsonify({"error": "Movie not found"}), 404

# # API route to get theater data
# @app.route('/getTheaters', methods=['GET'])
# def get_theaters():
#     conn = connect_db()
#     if not conn:
#         return jsonify({"error": "Database connection failed"}), 500
    
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM theaters")
#     theaters = cursor.fetchall()
#     cursor.close()
#     conn.close()

#     theater_list = []
#     for theater in theaters:
#         theater_data = {
#             "id": theater[0],
#             "name": theater[1],
#             "location": theater[2],
#             "show_date": theater[3].strftime('%Y-%m-%d') if isinstance(theater[3], datetime) else theater[3],
#             "address": theater[4]  # Use address instead of location
#         }
#         theater_list.append(theater_data)

#     return jsonify(theater_list)

# # Run the app
# if __name__ == '__main__':
#     app.run(debug=True)





from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Function to connect to the MySQL database
def connect_db():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='root',
            password='ritesh@7506',
            database='listing_movies'
        )
        return conn
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

# Function to format movie data
def format_movie_data(movie):
    return {
        "id": movie[0],
        "poster_url": movie[1] or 'default-poster.jpg',
        "title": movie[2] or 'No title available',
        "rating": float(movie[3]) if movie[3] is not None else 'N/A',
        "type": movie[4] or 'Type not available',
        "description": movie[5] or 'No description available'
    }

# API route to get all movies data from the `movies` table
@app.route('/getMovies', methods=['GET'])
def get_movies():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM movies")
    listing_movies = cursor.fetchall()
    cursor.close()
    conn.close()

    movie_list = [format_movie_data(movie) for movie in listing_movies]
    return jsonify(movie_list)

# API route to get recommended movies
@app.route('/getRecommendedMovies', methods=['GET'])
def get_recommended_movies():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM recommendedMovies")
    recommended_movies = cursor.fetchall()
    cursor.close()
    conn.close()

    recommended_list = [format_movie_data(movie) for movie in recommended_movies]
    return jsonify(recommended_list)

# API route to get popular movies
@app.route('/getPopularMovies', methods=['GET'])
def get_popular_movies():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM popularMovies")
    popular_movies = cursor.fetchall()
    cursor.close()
    conn.close()

    popular_list = [format_movie_data(movie) for movie in popular_movies]
    return jsonify(popular_list)

# API route to get all movies data from the `allMovies` table
@app.route('/getAllMovies', methods=['GET'])
def get_all_movies():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM allMovies")
    all_movies = cursor.fetchall()
    cursor.close()
    conn.close()

    all_movies_list = [format_movie_data(movie) for movie in all_movies]
    return jsonify(all_movies_list)

# API route to get movie details by ID and source
@app.route('/getMovieDetail', methods=['GET'])
def get_movie_detail():
    movie_id = request.args.get('id')
    source = request.args.get('source', 'allMovies')  # Default to 'allMovies'

    print(f"Received movie_id: {movie_id}, source: {source}")

    if not movie_id:
        return jsonify({"error": "No movie ID provided"}), 400

    if source not in ['movies', 'recommendedMovies', 'popularMovies', 'allMovies']:
        return jsonify({"error": "Invalid source"}), 400

    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM {source} WHERE id = %s", (movie_id,))
    movie = cursor.fetchone()
    cursor.close()
    conn.close()

    if movie:
        movie_data = format_movie_data(movie)
        return jsonify(movie_data)
    else:
        print(f"Movie with ID {movie_id} not found in {source} table")
        return jsonify({"error": "Movie not found"}), 404

# API route to get theater data
@app.route('/getTheaters', methods=['GET'])
def get_theaters():
    conn = connect_db()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM theaters")
    theaters = cursor.fetchall()
    cursor.close()
    conn.close()

    theater_list = []
    for theater in theaters:
        theater_data = {
            "id": theater[0],
            "name": theater[1],
            "location": theater[2],
            "show_date": theater[3].strftime('%Y-%m-%d') if isinstance(theater[3], datetime) else theater[3],
            "address": theater[4]
        }
        theater_list.append(theater_data)

    return jsonify(theater_list)

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
